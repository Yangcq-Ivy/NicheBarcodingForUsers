### Created on 2021-10-22 17:23:54
### A complete example (aCompletExample.r)
###

rm(list=ls())

#################################################################
### Scenario 0
### NBSI  DNA barcodes + coordinates of species distribution 
###       available (using online climate data)
#################################################################

library(NicheBarcoding)
library(ape)

#library(help=NicheBarcoding)


getwd()
#setwd("D:/R/myRprojects/NicheBarcodingForUsers")

ref.seq<-read.dna("ref_seq.fas",format="fasta")
que.seq<-read.dna("que_seq.fas",format="fasta")
ref.seq
que.seq

ref.infor<-read.csv("ref_infor.csv",header=T,row.names=1)
que.infor<-read.csv("que_infor.csv",header=T,row.names=1)
ref.infor
que.infor

envir<-NULL
#setwd()
### check whether there is environmental data downloaded.
### or downloaded the environmental data for the first time!
envir<-raster::getData("worldclim",download=TRUE,var="bio",res=10)
envir
class(envir)
getwd()

ref.add<-read.csv("ref_add.csv",header=T,row.names=1)
ref.add

if(class(envir) == "NULL"){

  NBSI.out<-NBSI(ref.seq,que.seq,
                 model="RF",independence=TRUE,
                 ref.add = ref.add,
                 variables="SELECT",
                 en.vir=NULL,bak.vir=NULL)

}else{

  ### else: just use the downloaded environmental data, you should setwd() to
  ### folders where environmental data live.
  en.vir<-raster::brick(envir)
  back<-dismo::randomPoints(mask=en.vir,n=5000,ext=NULL,extf=1.1,
                            excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,
                            lonlatCorrection=TRUE)
  bak.vir<-raster::extract(en.vir,back)

  NBSI.out<-NBSI(ref.seq,que.seq,
                 model="RF",independence=TRUE,
                 ref.add = ref.add,
                 variables="SELECT",
                 en.vir=en.vir,bak.vir=bak.vir)
}

NBSI.out
class(NBSI.out)
head(NBSI.out)

write.csv(NBSI.out,file="output.csv")



#################################################################
### Scenario 1 
### NBSI2   species identified by other methods or barcodes + 
###         coordinates of species distribution available 
###         (for using online climatic data)
#################################################################

library(NicheBarcoding)
library(ape)

barcode.identi.result<-read.csv("barcode_identi_result.csv",header=T,row.names=1)
ref.infor<-read.csv("ref_infor.csv",header=T,row.names=1)
que.infor<-read.csv("que_infor.csv",header=T,row.names=1)
ref.infor
que.infor

envir<-NULL
envir<-raster::getData("worldclim",download=TRUE,var="bio",res=10)

if(class(envir) == "NULL"){

  NBSI2.out1<-NBSI2(ref.infor=ref.infor,que.infor=que.infor,
                    barcode.identi.result=barcode.identi.result,
                    model="RF",variables="SELECT",
                    en.vir=NULL,bak.vir=NULL)

}else{
  en.vir<-raster::brick(envir)
  back<-dismo::randomPoints(mask=en.vir,n=5000,ext=NULL,extf=1.1,
                            excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,
                            lonlatCorrection=TRUE)
  bak.vir<-raster::extract(en.vir,back)

  NBSI2.out1<-NBSI2(ref.infor=ref.infor,que.infor=que.infor,
                    barcode.identi.result=barcode.identi.result,
                    model="RF",variables="SELECT",
                    en.vir=en.vir,bak.vir=bak.vir)

}

NBSI2.out1
write.csv(NBSI2.out1,file="output1.csv")


#################################################################
### Scenario 2
### NBSI2   species identified by other methods or barcodes + 
###         users possessing their own environmental data
#################################################################

library(NicheBarcoding)
library(ape)

barcode.identi.result<-read.csv("barcode_identi_result.csv",header=T,row.names=1)
ref.env<-read.csv("ref_env.csv",header=T,row.names=1)
que.env<-read.csv("que_env.csv",header=T,row.names=1)
ref.env
que.env

envir<-NULL
envir<-raster::getData("worldclim",download=FALSE,var="bio",res=10)

if(class(envir) == "NULL"){

  NBSI2.out2<-NBSI2(ref.infor=NULL,que.infor=NULL,
                   ref.env=ref.env,que.env=que.env,
                   barcode.identi.result=barcode.identi.result,
                   model="RF",variables="SELECT",
                   en.vir=NULL,bak.vir=NULL)

}else{
  en.vir<-raster::brick(envir)
  back<-dismo::randomPoints(mask=en.vir,n=5000,ext=NULL,extf=1.1,
                            excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,
                            lonlatCorrection=TRUE)
  bak.vir<-raster::extract(en.vir,back)

  NBSI2.out2<-NBSI2(ref.infor=NULL,que.infor=NULL,
                   ref.env=ref.env,que.env=que.env,
                   barcode.identi.result=barcode.identi.result,
                   model="RF",variables="SELECT",
                   en.vir=en.vir,bak.vir=bak.vir)
}

NBSI2.out2
write.csv(NBSI2.out2,file="output2.csv")






