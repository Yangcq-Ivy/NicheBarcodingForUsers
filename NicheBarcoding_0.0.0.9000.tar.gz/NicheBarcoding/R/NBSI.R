

#' Niche-model-Based Species Identification (NBSI).
#'
#' @description correct the barcoding identification result according to niche model.
#'
#' @param  ref.seq The reference dataset containing sample ID, taxon information, longitude and latitude and barcode sequences of each sample in class DNAbin.
#' @param  que.seq The query file containing sample ID, longitude and latitude and barcode sequences of each sample in class DNAbin.
#' @param  model A character string indicating which niche model will be used.
#'         Must be one of "RF" (default) or "MAXENT". "MAXENT" can only be applied when the java program paste(system.file(package="dismo"), "/java/maxent.jar", sep='') is exist.
#' @param  independence Logical. Whether the barcode sequences are related to the ecological variables?
#' @param  variables The identifier of selected bioclimate variables in class character.
#'         Default of "ALL" represents to use all the layers in en.vir; the alternative option of "SELECT" represents to randomly removed the highly-correlated variables (|r|??0.9) with the exception of one layer.
#' @param  en.vir The globle bioclimate data from "raster::getData" function in class RasterBrick.
#' @param  bak.vir Bioclimate variables of random backgroun points in class matrix.
#'
#' @return a dataframe of barcoding identification result for each query sample and their niche-based reliability.
#'
#' @keywords NBSI
#'
#' @export
#'
#' @import raster
#' @import maps
#' @import randomForest
#' @import dismo
#' @import e1071
#'
#' @author Cai-qing YANG. CNU, Beijing, CHINA.
#'         zhangab2008(at)mail.cnu.edu.cn
#'
#' @references Breiman, L. 2001. Random forests. Machine Learning 45(1): 5-32.
#' @references Liaw, A. and M. Wiener. 2002. Clasification and regression by randomForest. R News 2/3: 18-22.
#' @references Phillips S.J., Anderson R.P., Schapire R.E. 2006. Maximum entropy modeling of species geographic distributions. Ecological Modelling 190:231-259.
#' @references Zhang, A.B, Hao, M.D., Yang,C.Q., Shi, Z.Y. (2016). BarcodingR: an integrated R package for species identification using DNA barcodes. Methods in Ecology and Evolution. In press.
#' @references Jin,Q., H.L. Han, X.M. Hu, X.H. Li,C.D. Zhu,S. Y. W. Ho, R. D. Ward, A.B. Zhang . 2013. Quantifying Species Diversity with a DNA Barcoding-Based Method: Tibetan Moth Species (Noctuidae) on the Qinghai-Tibetan Plateau. PloS One 8: e644.
#' @references Hijmans, R. J., S. E. Cameron, J. L. Parra, P. G. Jones and A. Jarvis. 2005. Very high resolution interpolated climate surfaces for global land areas. International Journal of Climatology 25(15): 1965-1978.
#'
#' @note
#'
#' @examples
#' #load("Emberizidae.RData")
#' #load("en.vir_back.vir_5000.RData")
#' ### or if you want to obtain en.vir and bak.vir data by yourself, you can use the following functions: ###
#' #envir<-raster::getData("worldclim",download=TRUE,var="bio",res=2.5,lon=lon,lat=lat)
#' #en.vir<-brick(envir)
#' #back<-randomPoints(mask=en.vir,n=5000,ext=NULL,extf=1.1,excludep=TRUE,prob=FALSE,cellnumbers=FALSE,tryf=3,warn=2,lonlatCorrection=TRUE)
#' #bak.vir<-extract(en.vir,back)
#'
#' data(Emberizidae)
#' data(en.vir_back.vir_5000)
#' que.seq<-data[1:5,]
#' #rownames(que.seq)<-gsub("\\,[A-Za-z0-9\\.\\-\\_]*\\,","\\,",rownames(que.seq))
#' que.seq
#' ref.seq<-data[6:30,]
#' ref.seq
#'
#' NBSI.out<-NBSI(ref.seq,que.seq,model="RF",independence=T,variables="ALL",en.vir,bak.vir)
#' NBSI.out


#library(raster)
#library(maps)
#library(randomForest)
#library(dismo)
#library(e1071)
NBSI<-function(ref.seq,que.seq,model="RF",independence=TRUE,
               variables="ALL",en.vir,bak.vir){

  ref.infor<-extractSpeInfo(rownames(ref.seq))
  que.infor<-extractSpeInfo(rownames(que.seq))

  ### Species identification ####
  Bayesian.all.prob<-function(ref,Spp,que,all.ref.sp){

    rq<-rbind(ref,que)
    rq<-rq[,seg.sites(rq)]

    queIDs<-attr(que,"dimnames")[[1]]


    ref.constant.sites.removed<-rq[1:dim(ref)[1],]
    que.constant.sites.removed<-rq[-(1:dim(ref)[1]),]


    ref2<-as.character(ref.constant.sites.removed)
    ref2<-as.data.frame(ref2)
    que2<-as.character(que.constant.sites.removed)
    que2<-as.data.frame(que2)
    rq2<-rbind(ref2,que2)
    Spp<-c(Spp,queIDs)
    rq2$species<-as.factor(Spp)
    ref3<-rq2[1:dim(ref2)[1],]



    ref3$species<-with(ref3,as.factor(gsub(".+,","",sampleSpeNames)))


    que3<-rq2[-(1:dim(ref2)[1]),]
    del<-dim(que3)[2]
    que3<-que3[,-del]


    head(ref3);class(ref3);dim(ref3)

    rownames(ref3)<-1:dim(ref3)[1]

    Bayesian.trained <- naiveBayes(species ~ ., data = ref3)


    spe.inferred<-predict(Bayesian.trained, que3)
    spe.inferred.prob<-predict(Bayesian.trained, que3, type = "raw")

    all.prob<-t(spe.inferred.prob)
    spe.inferred.prob.order<-data.frame()
    for (sip in 1:length(all.ref.sp)){
      uspe<-as.character(all.ref.sp[sip])
      if (all(rownames(all.prob) != uspe) == TRUE){
        spe.inferred.prob.order<-rbind(spe.inferred.prob.order,cbind(uspe,tmp.sip=0))
      }else{
        tmp.sip<-as.numeric(all.prob[rownames(all.prob) == uspe,])
        spe.inferred.prob.order<-rbind(spe.inferred.prob.order,cbind(uspe,tmp.sip))
      }
    }

    Bayesian.prob<-apply(spe.inferred.prob,1,max)


    spe.inferred<-as.character(spe.inferred)



    output.identified<-data.frame(queIDs=queIDs,
                                  spe.Identified=spe.inferred,
                                  Bayesian.prob=Bayesian.prob)



    out<-list(output_identified=output.identified,all_prob=spe.inferred.prob.order)


    class(out) <- c("BarcodingR")



    return(out)
  }

  row.names(ref.seq)<-gsub("\\,[0-9\\.\\ \\-]*$","",rownames(ref.seq));ref.seq
  row.names(que.seq)<-gsub("\\,[0-9\\.\\ \\-]*$","",rownames(que.seq));que.seq
  sampleSpeNames<-attr(ref.seq,"dimnames")[[1]]
  mpattern<-".+,"
  Spp<-gsub(mpattern,"",sampleSpeNames)
  all.ref.sp<-unique(ref.infor[,3])

  all_prob<-list()
  output_identified<-data.frame()
  for (nq in 1:nrow(que.seq)){
    bsi<-Bayesian.all.prob(ref.seq,Spp,que.seq[nq,],all.ref.sp)
    all_prob[[nq]]<-bsi$all_prob
    output_identified<-rbind(output_identified,bsi$output_identified)
    if (nrow(que.seq) == 1){
      cat("DNA Barcoding: 100% Done!\n")
    }else if (nq == 1){
      cat("DNA Barcoding: 0%[=")
    }else if (nq == nrow(que.seq)){
      cat("=]100% Done!\n")
    }else{
      cat("=")
    }
  }

  BSI.out<-data.frame(queryID = rownames(que.seq),
                      species.identified = output_identified$spe.Identified,
                      barcoding.based.prob = output_identified$Bayesian.prob)
  BSI.out

  ### Bioclimatic variables ####
  ref.range<-data.frame()
  for (su in 1:length(all.ref.sp)){
    prese.lonlat<-ref.infor[ref.infor$species %in% all.ref.sp[su],]
    range.lon=min(diff(range(prese.lonlat[,4])),(abs(min(prese.lonlat[,4])-(-180))+abs(max(prese.lonlat[,4])-180)))
    range.lat=diff(range(prese.lonlat[,5]))
    ref.range<-rbind(ref.range,cbind(range.lon,range.lat))
  }
  lon.mean<-mean(ref.range[-which(ref.range[,1] == 0),1])
  lat.mean<-mean(ref.range[-which(ref.range[,2] == 0),2])

  samp.env<-data.frame()
  samp.points<-data.frame()
  for (su in 1:length(all.ref.sp)){
    prese.lonlat<-ref.infor[ref.infor$species %in% all.ref.sp[su],]
    present.points<-pseudo.present.points(prese.lonlat[,3:5],10,lon.mean,lat.mean,en.vir,map=F)
    present.points[,1]<-gsub("Simulation",present.points[1,1],present.points[,1]);present.points
    samp.points<-rbind(samp.points,present.points)

    prese.env<-extract(en.vir,present.points[,2:3])
    if (!all(is.na(prese.env[,1])==FALSE)){
      nonerr.env<-prese.env[-which(is.na(prese.env[,1])==TRUE),]
      if (is.null(dim(nonerr.env))==TRUE){
        prese.env<-t(as.data.frame(nonerr.env))
        row.names(prese.env)=NULL
      }else if (dim(nonerr.env)[1]==0){
        stop ("Please check the coordinate of ",all.ref.sp[su]," !\n")
      }else{
        prese.env<-nonerr.env
      }
    }

    spe.env<-cbind(Species=as.character(all.ref.sp[su]),prese.env)
    samp.env<-rbind(samp.env,spe.env)

    if (length(all.ref.sp) == 1){
      cat("Variable Extracting: 100% Done!\n")
    }else if (su == 1){
      cat("Variable Extracting: 0%[=")
    }else if (su == length(all.ref.sp)){
      cat("=]100% Done!\n")
    }else{
      cat("=")
    }
    #cat("Extracting:",su,"/",length(all.ref.sp),as.character(all.ref.sp[su]),"\n")
  }
  samp.env[,2:ncol(samp.env)]<-apply(samp.env[,2:ncol(samp.env)],FUN=as.integer,MARGIN=2)
  head(samp.env);dim(samp.env)

  # Variable selection
  eff.samp.env<-samp.env
  if (variables == "SELECT"){
    for (eff in 1:ncol(eff.samp.env)){
      rs<-abs(cor(eff.samp.env[,-1]))
      cor.vir<-c()
      for (r in 1:nrow(rs)){
        tmp<-rs[r,which(rs[r,] >= 0.9 & rs[r,] != 1)]
        if (length(tmp) != 0){
          cor.vir<-c(cor.vir,names(tmp))
        }
      }
      freq.vir<-table(cor.vir);freq.vir
      if (length(freq.vir) != 0){
        max.freq.vir<-names(freq.vir[freq.vir == max(freq.vir)])
        max.freq.vir<-max.freq.vir[sample(1:length(max.freq.vir),size=1)]
        eff.samp.env<-eff.samp.env[,-which(colnames(eff.samp.env)==max.freq.vir)]
      }else{
        break
      }
    }
    colnames(eff.samp.env)
    eff.list<-colnames(eff.samp.env)[-1]
  }

  ### Niche modeling ####
  # (1) Niche modeling and self-inquery of ref
  spe.niche<-list()
  niche.ref.prob<-list()
  for (siu in 1:length(all.ref.sp)){
    prese.env<-eff.samp.env[gsub(".+,","",eff.samp.env[,1]) %in% all.ref.sp[siu],-1]
    prese.env<-na.omit(prese.env)
    if (dim(prese.env)[1]==1){
      prese.env<-rbind(prese.env,prese.env)
      warning ("The model may not be accurate because there is only one record of ",all.ref.sp[siu],"!\n")
    }

    if (model == "RF"){
      mod<-niche.Model.Build(prese=NULL,absen=NULL,prese.env=prese.env,absen.env=NULL,model="RF",bak.vir=bak.vir,en.vir=en.vir)
      spe.niche[[siu]]<-mod$model
      spe.var<-apply(prese.env,FUN=as.numeric,MARGIN=2)
      ref.HSI<-predict(mod$model,spe.var,type="prob")
      niche.ref.prob[[siu]]<-min(ref.HSI[,2])
    }else if (model == "MAXENT"){
      mod<-niche.Model.Build(prese=NULL,absen=NULL,prese.env=prese.env,absen.env=NULL,model="MAXENT",bak.vir=bak.vir,en.vir=en.vir)
      spe.niche[[siu]]<-mod$model
      spe.var<-apply(prese.env,FUN=as.numeric,MARGIN=2)
      ref.HSI<-dismo::predict(mod$model,spe.var,args='outputformat=logistic')
      niche.ref.prob[[siu]]<-min(ref.HSI)
    }

    if (length(all.ref.sp) == 1){
      cat("Niche Modeling: 100% Done!\n")
    }else if (siu == 1){
      cat("Niche Modeling: 0%[=")
    }else if (siu == length(all.ref.sp)){
      cat("=]100% Done!\n")
    }else{
      cat("=")
    }
    #cat("Modeling:",siu,"/",length(all.ref.sp),"\n")
  }
  #spe.niche
  niche.ref.prob

  # (2) Prediction of query samples and calculation of Prob(Sid)
  que.vari<-extract(en.vir,que.infor[,4:5])
  if (nrow(que.vari) == 1){
    que.vari<-que.vari[,colnames(que.vari) %in% colnames(eff.samp.env)]
    que.vari<-t(as.data.frame(que.vari))
  }else{
    que.vari<-apply(que.vari,MARGIN=2,as.integer)
    que.vari<-que.vari[,colnames(que.vari) %in% colnames(eff.samp.env)]
  }

  result<-data.frame()
  for(n in 1:nrow(que.vari)){
    queID<-as.character(que.infor[n,2])
    target.spe<-as.character(BSI.out[n,2])
    spe.index<-grep(paste(target.spe,"$",sep=""),all.ref.sp,fixed=F)
    model.spe<-spe.niche[[spe.index]]

    que.niche<-t(as.matrix(que.vari[n,]))
    if (all(is.na(que.niche)) == TRUE){
      stop ("Please check the coordinate of ",queID," !\n")
    }else{
      if (model == "RF"){
        que.HSI<-predict(model.spe,que.niche,type="prob")
        que.prob<-que.HSI[,2]
        ref.prob<-niche.ref.prob[[spe.index]]
      }else if (model == "MAXENT"){
        que.HSI<-dismo::predict(model.spe,que.niche,args='outputformat=logistic')
        que.prob<-que.HSI
        ref.prob<-niche.ref.prob[[spe.index]]
      }

      # (1) Calculation for Bayes Theorem
      sum.pe<-0
      b.prob<-all_prob[[n]]
      b.prob[,2]<-as.numeric(as.character(b.prob[,2]))
      for (pe in 1:length(all.ref.sp)){
        if (model == "RF"){
          que.pe.HSI<-predict(spe.niche[[pe]],que.niche,type="prob")
          que.pe.prob<-que.pe.HSI[,2];que.pe.prob
        }else if (model == "MAXENT"){
          que.pe.HSI<-dismo::predict(spe.niche[[pe]],que.niche,args='outputformat=logistic')
          que.pe.prob<-que.pe.HSI;que.pe.prob
        }
        bsi.prob<-b.prob[as.character(b.prob[,1]) %in% as.character(all.ref.sp[pe]),2]
        if (length(bsi.prob) == 0) { bsi.prob<-0 }
        tmp.pe<-bsi.prob*que.pe.prob
        sum.pe=sum.pe+tmp.pe
      }

      Pe<-sum.pe
      if (Pe == 0) { Pe<-1e-07 }
      Pb<-BSI.out[n,3]
      Peb<-que.prob
      Pbe<-(Peb*Pb)/Pe

      # (2) Calculation of probability
      CF=que.prob/ref.prob
      NicoB.prob=Pb*CF
      if (CF > 1){ CF=1 }
      if (NicoB.prob > 1){ NicoB.prob=1 }
    }

    res0<-cbind(Pb,ref.prob,que.prob,CF,Pbe,NicoB.prob)
    res0<-cbind(as.character(BSI.out[n,1]),target.spe,round(res0,4))
    result<-rbind(result,res0)
  }
  colnames(result)<-c("queID","barcode.target.spe","P(B)","min(P(ER))","P(Ek)",
                      "Prob(Sid).TSI","Prob(Sid).CI.cor","Prob(Sid).CI.unc")

  if (independence == TRUE){
    result<-as.data.frame(result[,-7])
  }else if (independence == FALSE){
    result<-as.data.frame(result[,-8])
  }

  return(result)
}

# The end of NBSI #

