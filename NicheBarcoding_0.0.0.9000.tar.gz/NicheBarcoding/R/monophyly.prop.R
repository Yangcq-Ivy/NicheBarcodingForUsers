

#' Analyses of phylogenetic monophyletic proportion
#'
#' @description calculate the proportion of monophyly group on a tree.
#'
#' @param  phy A tree of class phylo.
#' @param  sppVector Species vector.
#' @param  singletonsMono Logical. Should singletons (i.e. only a single specimen representing that species) be treated as monophyletic? 
#'         Default of TRUE. Possible values of FALSE and NA.
#'         
#' @return a list containing proportion and number of monophyly group.
#'         a set monophyly and of non-monophyly group names.
#' 
#' @keywords monophyly.prop
#' 
#' @export 
#' 
#' @import ape
#' @import spider
#' 
#' @author Ai-bing ZHANG, PhD. CNU, Beijing, CHINA.
#'         zhangab2008(at)mail.cnu.edu.cn
#' 
#' @references 
#' 
#' @note
#' 
#' @examples
#' tree<-rtree(20)
#' tree$tip.label<-sample(tree$tip.label[1:10],size=20,replace = TRUE)
#' plot(tree) 
#' sppVector<-tree$tip.label 
#' MP<-monophyly.prop(tree,sppVector,singletonsMono = TRUE)
#' MP


#library(spider)
monophyly.prop<-function(phy,sppVector,singletonsMono = TRUE){
  mono<-monophyly(phy, sppVector, pp = NA, singletonsMono = TRUE)
  spp.unique<-unique(sppVector)
  
  mono.list<-spp.unique[mono]
  
  mono[mono==TRUE]<-1
  mono[mono==FALSE]<-0
  no.mono<-sum(mono)
  
  non.mono.list<-spp.unique[!mono]
  non.mono.list
  mono.prop<-no.mono/length(mono)
  OUT<-list(mono.prop=mono.prop,
            no.mono=no.mono,
            mono.list=mono.list,
            non.mono.list=non.mono.list
  )
  return(OUT)
}

# The end of monophyly.prop #

