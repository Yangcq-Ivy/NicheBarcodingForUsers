

#' Principal component analysis of ecological niche among unknown species and the potential species to which they may belong
#'
#' @description determine whether unknon species belong to a known species through principal component analysis of ecological niche according to their distribution information.
#'
#' @param  ref.lonlat The longitude and latitude of the known species in class data.frame.
#' @param  que.lonlat The longitude and latitude of the unknown species in class data.frame.
#' @param  en.vir The globle bioclimate data from "raster::getData" function in class RasterBrick.
#'
#' @return a list containing inportance and loadings of the components.
#' @return a dataframe of points that within the 95% confidence interval of the reference dataset ecological space.
#' @return a figure shows whether the query points (blue solid circles) are located in the 95%CI range of the niche space of reference species.
#'
#' @keywords niche.PCA
#'
#' @export
#'
#' @import raster
#'
#' @author Cai-qing YANG. CNU, Beijing, CHINA.
#'         zhangab2008(at)mail.cnu.edu.cn
#'
#' @references
#'
#' @note
#'
#' @examples
#' # load("en.vir_back.vir_5000.RData")
#' data(en.vir_back.vir_5000)
#' ### or if you want to obtain en.vir and bak.vir data by yourself, you can use the following functions: ###
#' #envir<-raster::getData("worldclim",download=TRUE,var="bio",res=2.5,lon=lon,lat=lat)
#' #en.vir<-brick(envir)
#'
#' data<-data.frame(species=rep("Acosmeryx anceus",3),Lon=c(145.380,145.270,135.461),Lat=c(-16.4800,-5.2500,-16.0810))
#' simuSites<-pseudo.present.points(data,500,4,2,en.vir)
#' ref.lonlat<-simuSites[1:480,]
#' que.lonlat<-simuSites[481:500,]
#'
#' nPCA<-niche.PCA(ref.lonlat,que.lonlat,en.vir)
#' nPCA$summary
#' nPCA$que.CI


#library(raster)
niche.PCA<-function(ref.lonlat,que.lonlat,en.vir){
  nPCA<-list()

  # ref.lonlat must be more than 19 rows!
  if (dim(ref.lonlat)[1] < 19){
    cat ("ref.lonlat must be more than 19 points!\n")
    cat ("Generating the pseudo present points ......\n")
    ref.lonlat<-pseudo.present.points(ref.lonlat,19,50,1)
  }

  # Extract the environment variables
  data.var<-extract(en.vir,ref.lonlat[,2:3])
  que.var<-extract(en.vir,que.lonlat[,2:3])

  # PCA analysis
  env.pr<-princomp(data.var,cor=TRUE)
  summary<-summary(env.pr,loadings=TRUE)
  nPCA$summary<-summary

  # Calculate principal component according to loading coefficient
  data.pca1<-t(apply(data.var,FUN=function(x){sum(summary$loadings[1:19,1]*x)},MARGIN=1))
  data.pca1<-scale(data.pca1[1,],center=T,scale=T)
  data.pca2<-t(apply(data.var,FUN=function(x){sum(summary$loadings[1:19,2]*x)},MARGIN=1))
  data.pca2<-scale(data.pca2[1,],center=T,scale=T)
  que.pca1<-t(apply(que.var,FUN=function(x){sum(summary$loadings[1:19,1]*x)},MARGIN=1))
  que.pca1<-scale(que.pca1[1,],center=T,scale=T)
  que.pca2<-t(apply(que.var,FUN=function(x){sum(summary$loadings[1:19,2]*x)},MARGIN=1))
  que.pca2<-scale(que.pca2[1,],center=T,scale=T)

  # Show all ref points & que points
  par(mar=c(6,5,5,8))
  plot(x=data.pca1,y=data.pca2,
       xlab="PCA1",ylab="PCA2",
       main="PCA Analysis in Both Ref & Que")
  points(x=que.pca1,y=que.pca2,col="blue",pch=19)
  legend(x="right",inset=-0.3,
         col=c("black","blue"),
         pch=c(1,19),
         legend=c("Ref.points","Que.points"),
         horiz=F,
         xpd=T,
         bty="o")

  # Calculate the 95%CI & draw them as boundaries
  CI.pca1<-quantile(data.pca1,prob=c(0.025,0.975),na.rm=T)
  CI.pca2<-quantile(data.pca2,prob=c(0.025,0.975),na.rm=T)
  abline(v=CI.pca1[1],col="red",lty=2)
  text(x=CI.pca1[1],y=min(data.pca2),"2.5%",col="red")
  abline(v=CI.pca1[2],col="red",lty=2)
  text(x=CI.pca1[2],y=min(data.pca2),"97.5%",col="red")
  abline(h=CI.pca2[1],col="red",lty=2)
  text(x=min(data.pca1),y=CI.pca2[1],"2.5%",col="red")
  abline(h=CI.pca2[2],col="red",lty=2)
  text(x=min(data.pca1),y=CI.pca2[2],"97.5%",col="red")

  index=which(que.pca1 < CI.pca1[1] | que.pca1 > CI.pca1[2] | que.pca2 < CI.pca2[1] | que.pca2 > CI.pca2[2])
  que.CI<-que.lonlat[-index,]
  nPCA$que.CI<-que.CI

  return(nPCA)
}

# The end of niche.PCA #


