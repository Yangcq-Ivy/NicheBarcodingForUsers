

#' Mantel test between interspecific pairwise genetic distance and ecological distance
#'
#' @description determine the independence between sequences and niches of a reference dataset in species level.
#'
#' @param  fas The reference dataset containing sample ID, taxon information, longitude and latitude and barcode sequences of each sample in class DNAbin.
#' @param  dna.model A character string specifying the evolutionary model to be used; 
#'         must be one of "raw" (default), "N", "TS", "TV", "JC69", "K80", "F81", "K81", "F84", "BH87", "T92", "TN93", "GG95", "logdet", "paralin", "indel", or "indelblock".
#' @param  ecol.dist.method The distance measure to be used;
#'         must be one of "euclidean" (default), "maximum", "manhattan", "canberra", "binary" or "minkowski".       
#' @param  mantel.method Correlation method, as accepted by cor: "pearson", "spearman" (default) or "kendall".
#' @param  permutations The number of permutations required.
#'         
#' @return the Mantel statistic.
#'         the empirical significance level from permutations.
#'         a matrix of interspecific pairwise genetic distance.
#'         a matrix of interspecific pairwise ecological distance.
#' 
#' @keywords spe.mantel.test
#' 
#' @export 
#' 
#' @import vegan
#' 
#' @author Cai-qing YANG. CNU, Beijing, CHINA.
#'         zhangab2008(at)mail.cnu.edu.cn
#' 
#' @references Mantel N. 1967. The detection of disease clustering and a generalized regression approach. Can. Res. 27:209-220. 
#' @references Oksanen J., Blanchet F.G., Friendly M., Kindt R., Legendre P., McGlinn D., Minchin P.R., O??Hara R.B., Simpson G.L., Solymos P., Stevens M.H.H., Szoecs E., Wagner H. 2016. vegan: Community Ecology Package < https://CRAN.R-project.org/package= vegan >. r package version 2.5-6.
#' 
#' @note
#' 
#' @examples
#' #load("Emberizidae.RData")
#' 
#' data(Emberizidae)
#' spe.mantel<-spe.mantel.test(data)
#' spe.mantel$MantelStat.r
#' spe.mantel$p.value


#library(vegan)
spe.mantel.test<-function(fas,dna.model="raw",ecol.dist.method="euclidean",
                          mantel.method="spearman",permutations=999){
  niche.stand<-function(x){
    (x-env.range["min",])/(env.range["max",]-env.range["min",])
  }
  env.range<-matrix(c(-278,319,9,213,8,96,64,22704,-86,489,-559,258,53,725,-278,376,-501,365,-127,382,-506,289,0,10577,0,2437,0,697,0,265,0,6586,0,2319,0,5040,0,4580),2,19)
  rownames(env.range)<-c("min","max");colnames(env.range)<-paste("bio",1:19,sep="")
  env.range
  
  infor<-extractSpeInfo(labels(fas));head(infor)
  unique<-unique(infor$species)
  nspe<-length(unique)
  
  result<-list()
  genet.matrix<-matrix(nrow=nspe,ncol=nspe)
  ecol.matrix<-matrix(nrow=nspe,ncol=nspe)
  for (spe1 in 1:(nspe-1)){
    cat (paste(">>> ",spe1,"/",nspe," ",as.character(unique[spe1]),"\n",sep=""))
    for (spe2 in (spe1+1):nspe){
      sp1.fas<-fas[infor[,3] %in% unique[spe1],]
      sp1.infor<-extractSpeInfo(labels(sp1.fas))
      sp1.vari<-extract(en.vir,sp1.infor[,4:5])
      if (nrow(sp1.vari) == 1){
        sp1.vari<-apply(sp1.vari,FUN=as.numeric,MARGIN=2)
      }else{
        sp1.vari<-apply(apply(sp1.vari,FUN=as.numeric,MARGIN=2),FUN=mean,MARGIN=2)
      }
      sp1.vari<-niche.stand(sp1.vari)    
      
      sp2.fas<-fas[infor[,3] %in% unique[spe2],]
      sp2.infor<-extractSpeInfo(labels(sp2.fas))
      sp2.vari<-extract(en.vir,sp2.infor[,4:5])
      if (nrow(sp2.vari) == 1){
        sp2.vari<-apply(sp2.vari,FUN=as.numeric,MARGIN=2)
      }else{
        sp2.vari<-apply(apply(sp2.vari,FUN=as.numeric,MARGIN=2),FUN=mean,MARGIN=2)
      }
      sp2.vari<-niche.stand(sp2.vari)
      
      sel.fas<-rbind(sp1.fas,sp2.fas)
      genet.dist<-as.matrix(dist.dna(sel.fas,dna.model))
      genet.dist12<-genet.dist[1:nrow(sp1.fas),(nrow(sp1.fas)+1):(nrow(sp1.fas)+nrow(sp2.fas))]
      if (length(which(is.nan(genet.dist12))) != 0){
        warning ("Sequences of ",as.character(unique[spe1])," and ",as.character(unique[spe2]),
                 " are very different, so that the model of dist.dna have been changed to \"raw\".\n")
        genet.dist<-as.matrix(dist.dna(sel.fas,"raw"))
        genet.dist12<-genet.dist[1:nrow(sp1.fas),(nrow(sp1.fas)+1):(nrow(sp1.fas)+nrow(sp2.fas))]
      }
      genet.matrix[spe2,spe1]<-mean(genet.dist12)
      
      sel.envir<-rbind(sp1.vari,sp2.vari)
      ecol.dist<-as.matrix(dist(sel.envir,method=ecol.dist.method))
      ecol.matrix[spe2,spe1]<-ecol.dist[2,1]
    }
  }
  row.names(genet.matrix)<-as.character(unique)
  colnames(genet.matrix)<-as.character(unique)
  row.names(ecol.matrix)<-as.character(unique)
  colnames(ecol.matrix)<-as.character(unique)  
  
  test<-mantel(as.dist(genet.matrix),as.dist(ecol.matrix),
               mantel.method,permutations);test
  
  result$MantelStat.r<-test$statistic
  result$p.value<-test$signif
  result$genet.matrix<-genet.matrix
  result$ecol.matrix<-ecol.matrix
  return (result)
}

# The end of spe.mantel.test #

